module com.example.algoritmica {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.algoritmica to javafx.fxml;
    exports com.example.algoritmica;
}