package com.example.algoritmica;
import java.util.Scanner;
public class Exo2 {


}

