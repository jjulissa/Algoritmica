package com.example.algoritmica;

public class Ejercicio2 {

    public static void main(String[] args) {

    }
}
